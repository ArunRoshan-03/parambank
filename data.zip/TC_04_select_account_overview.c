TC_04_select_account_overview()
{

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

	lr_think_time(5);

	web_url("overview.htm", 
		"URL=https://parabank.parasoft.com/parabank/overview.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://parabank.parasoft.com/parabank/openaccount.htm", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_url("accounts_2", 
		"URL=https://parabank.parasoft.com/parabank/services_proxy/bank/customers/12989/accounts", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://parabank.parasoft.com/parabank/overview.htm", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/parabank/images/gradhead.png", "Referer=https://parabank.parasoft.com/parabank/style.css", ENDITEM, 
		"Url=/parabank/images/gradhover.png", "Referer=https://parabank.parasoft.com/parabank/style.css", ENDITEM, 
		"Url=/parabank/images/gradback.png", "Referer=https://parabank.parasoft.com/parabank/style.css", ENDITEM, 
		LAST);

	return 0;
}
