TC_02_register_user()
{

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

	lr_think_time(6);

	web_url("register.htm;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", 
		"URL=https://parabank.parasoft.com/parabank/register.htm;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=images/header-main.jpg", ENDITEM, 
		"Url=images/bullet2-hover.gif", "Referer=https://parabank.parasoft.com/parabank/template.css", ENDITEM, 
		LAST);

	lr_think_time(46);

	web_submit_form("register.htm", 
		"Snapshot=t5.inf", 
		ITEMDATA, 
		"Name=customer.firstName", "Value=Arun", ENDITEM, 
		"Name=customer.lastName", "Value=roshan", ENDITEM, 
		"Name=customer.address.street", "Value=new street cantonment", ENDITEM, 
		"Name=customer.address.city", "Value=tamilnadu", ENDITEM, 
		"Name=customer.address.state", "Value=trichy", ENDITEM, 
		"Name=customer.address.zipCode", "Value=620001", ENDITEM, 
		"Name=customer.phoneNumber", "Value=9344189391", ENDITEM, 
		"Name=customer.ssn", "Value=1234567890", ENDITEM, 
		"Name=customer.username", "Value=Admin", ENDITEM, 
		"Name=customer.password", "Value=Atmecs@123", ENDITEM, 
		"Name=repeatedPassword", "Value=Atmecs@123", ENDITEM, 
		LAST);

	lr_think_time(31);

	web_submit_form("register.htm_2", 
		"Snapshot=t6.inf", 
		ITEMDATA, 
		"Name=customer.firstName", "Value=Arun", ENDITEM, 
		"Name=customer.lastName", "Value=roshan", ENDITEM, 
		"Name=customer.address.street", "Value=new street cantonment", ENDITEM, 
		"Name=customer.address.city", "Value=tamilnadu", ENDITEM, 
		"Name=customer.address.state", "Value=trichy", ENDITEM, 
		"Name=customer.address.zipCode", "Value=620001", ENDITEM, 
		"Name=customer.phoneNumber", "Value=9344189391", ENDITEM, 
		"Name=customer.ssn", "Value=1234567890", ENDITEM, 
		"Name=customer.username", "Value=Admin_user", ENDITEM, 
		"Name=customer.password", "Value=Atmecs@123", ENDITEM, 
		"Name=repeatedPassword", "Value=Atmecs@123", ENDITEM, 
		EXTRARES, 
		"Url=images/header-customer.jpg", ENDITEM, 
		LAST);

	return 0;
}
