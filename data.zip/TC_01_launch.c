TC_01_launch()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

	web_url("index.htm", 
		"URL=https://parabank.parasoft.com/parabank/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../favicon.ico", ENDITEM, 
		"Url=images/header-main.jpg;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		LAST);

	lr_think_time(3);

	web_custom_request("ocsp.sectigo.com", 
		"URL=http://ocsp.sectigo.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0R0P0N0L0J0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x11\\x00\\x86&\\xA3\\xBB\\xC9\\xCDj\\xA8\\xA4\\xE7\\x91\\xA2\\x1A\\x8F\\xF7\\x01", 
		LAST);

	web_custom_request("ocsp.sectigo.com_2", 
		"URL=http://ocsp.sectigo.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0R0P0N0L0J0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x11\\x00\\x86&\\xA3\\xBB\\xC9\\xCDj\\xA8\\xA4\\xE7\\x91\\xA2\\x1A\\x8F\\xF7\\x01", 
		EXTRARES, 
		"Url=https://parabank.parasoft.com/parabank/images/main-bg.gif", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/topbg.gif", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/bullet-hover.gif", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/bullet-normal.gif", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/aboutus-normal.gif", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/contact-normal.gif", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/bodybg.gif", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/button-bgr.png", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/bullet2-normal.gif", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/sky-color-bg.gif", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/icon2.jpg", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/icon4.jpg", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/home-normal.gif", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/footerbg.gif", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		"Url=https://parabank.parasoft.com/parabank/images/atmhand.jpg", "Referer=https://parabank.parasoft.com/parabank/template.css;jsessionid=4A318A6A82FEA4C50D362738D59A0B2B", ENDITEM, 
		LAST);

	web_websocket_send("ID=1", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1693364236626\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 1 received buffer WebSocketReceive0*/

	return 0;
}
