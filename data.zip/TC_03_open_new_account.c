TC_03_open_new_account()
{

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

	lr_think_time(5);

	web_url("openaccount.htm", 
		"URL=https://parabank.parasoft.com/parabank/openaccount.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://parabank.parasoft.com/parabank/register.htm", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("accounts", 
		"URL=https://parabank.parasoft.com/parabank/services_proxy/bank/customers/12989/accounts", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://parabank.parasoft.com/parabank/openaccount.htm", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(3);

	web_custom_request("createAccount", 
		"URL=https://parabank.parasoft.com/parabank/services_proxy/bank/createAccount?customerId=12989&newAccountType=1&fromAccountId=14787", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://parabank.parasoft.com/parabank/openaccount.htm", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=utf-8", 
		LAST);

	return 0;
}
